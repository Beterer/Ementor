﻿namespace Ementor
{
    public class EmentorConsts
    {
        public const string LocalizationSourceName = "Ementor";
    }
}