﻿using Abp.Application.Editions;

namespace Ementor.Editions
{
    public class EditionManager : AbpEditionManager
    {

    }
}
